package com.mojang.blaze3d.platform;

import java.nio.ByteBuffer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.lwjgl.system.MemoryUtil;

@OnlyIn(Dist.CLIENT)
public class MemoryTracker {
   private static final MemoryUtil.MemoryAllocator ALLOCATOR = MemoryUtil.getAllocator(false);

   public static ByteBuffer create(int size) {
      long i = ALLOCATOR.malloc((long)size);
      if (i == 0L) {
         throw new OutOfMemoryError("Failed to allocate " + size + " bytes");
      } else {
         return MemoryUtil.memByteBuffer(i, size);
      }
   }

   public static ByteBuffer resize(ByteBuffer buffer, int byteSize) {
      long i = ALLOCATOR.realloc(MemoryUtil.memAddress0(buffer), (long)byteSize);
      if (i == 0L) {
         throw new OutOfMemoryError("Failed to resize buffer from " + buffer.capacity() + " bytes to " + byteSize + " bytes");
      } else {
         return MemoryUtil.memByteBuffer(i, byteSize);
      }
   }
}
