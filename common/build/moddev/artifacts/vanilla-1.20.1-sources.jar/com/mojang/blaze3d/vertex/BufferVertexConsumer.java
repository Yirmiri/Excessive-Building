package com.mojang.blaze3d.vertex;

import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public interface BufferVertexConsumer extends VertexConsumer {
   VertexFormatElement currentElement();

   void nextElement();

   void putByte(int index, byte byteValue);

   void putShort(int index, short shortValue);

   void putFloat(int index, float floatValue);

   default VertexConsumer vertex(double x, double y, double z) {
      if (this.currentElement().getUsage() != VertexFormatElement.Usage.POSITION) {
         return this;
      } else if (this.currentElement().getType() == VertexFormatElement.Type.FLOAT && this.currentElement().getCount() == 3) {
         this.putFloat(0, (float)x);
         this.putFloat(4, (float)y);
         this.putFloat(8, (float)z);
         this.nextElement();
         return this;
      } else {
         throw new IllegalStateException();
      }
   }

   default VertexConsumer color(int red, int green, int blue, int alpha) {
      VertexFormatElement vertexformatelement = this.currentElement();
      if (vertexformatelement.getUsage() != VertexFormatElement.Usage.COLOR) {
         return this;
      } else if (vertexformatelement.getType() == VertexFormatElement.Type.UBYTE && vertexformatelement.getCount() == 4) {
         this.putByte(0, (byte)red);
         this.putByte(1, (byte)green);
         this.putByte(2, (byte)blue);
         this.putByte(3, (byte)alpha);
         this.nextElement();
         return this;
      } else {
         throw new IllegalStateException();
      }
   }

   default VertexConsumer uv(float u, float v) {
      VertexFormatElement vertexformatelement = this.currentElement();
      if (vertexformatelement.getUsage() == VertexFormatElement.Usage.UV && vertexformatelement.getIndex() == 0) {
         if (vertexformatelement.getType() == VertexFormatElement.Type.FLOAT && vertexformatelement.getCount() == 2) {
            this.putFloat(0, u);
            this.putFloat(4, v);
            this.nextElement();
            return this;
         } else {
            throw new IllegalStateException();
         }
      } else {
         return this;
      }
   }

   default VertexConsumer overlayCoords(int u, int v) {
      return this.uvShort((short)u, (short)v, 1);
   }

   default VertexConsumer uv2(int u, int v) {
      return this.uvShort((short)u, (short)v, 2);
   }

   default VertexConsumer uvShort(short u, short v, int index) {
      VertexFormatElement vertexformatelement = this.currentElement();
      if (vertexformatelement.getUsage() == VertexFormatElement.Usage.UV && vertexformatelement.getIndex() == index) {
         if (vertexformatelement.getType() == VertexFormatElement.Type.SHORT && vertexformatelement.getCount() == 2) {
            this.putShort(0, u);
            this.putShort(2, v);
            this.nextElement();
            return this;
         } else {
            throw new IllegalStateException();
         }
      } else {
         return this;
      }
   }

   default VertexConsumer normal(float x, float y, float z) {
      VertexFormatElement vertexformatelement = this.currentElement();
      if (vertexformatelement.getUsage() != VertexFormatElement.Usage.NORMAL) {
         return this;
      } else if (vertexformatelement.getType() == VertexFormatElement.Type.BYTE && vertexformatelement.getCount() == 3) {
         this.putByte(0, normalIntValue(x));
         this.putByte(1, normalIntValue(y));
         this.putByte(2, normalIntValue(z));
         this.nextElement();
         return this;
      } else {
         throw new IllegalStateException();
      }
   }

   static byte normalIntValue(float num) {
      return (byte)((int)(Mth.clamp(num, -1.0F, 1.0F) * 127.0F) & 255);
   }
}
