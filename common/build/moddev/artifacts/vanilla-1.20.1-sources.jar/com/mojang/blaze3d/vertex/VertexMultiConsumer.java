package com.mojang.blaze3d.vertex;

import java.util.function.Consumer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class VertexMultiConsumer {
   public static VertexConsumer create() {
      throw new IllegalArgumentException();
   }

   public static VertexConsumer create(VertexConsumer consumer) {
      return consumer;
   }

   public static VertexConsumer create(VertexConsumer first, VertexConsumer second) {
      return new VertexMultiConsumer.Double(first, second);
   }

   public static VertexConsumer create(VertexConsumer... delegates) {
      return new VertexMultiConsumer.Multiple(delegates);
   }

   @OnlyIn(Dist.CLIENT)
   static class Double implements VertexConsumer {
      private final VertexConsumer first;
      private final VertexConsumer second;

      public Double(VertexConsumer first, VertexConsumer second) {
         if (first == second) {
            throw new IllegalArgumentException("Duplicate delegates");
         } else {
            this.first = first;
            this.second = second;
         }
      }

      public VertexConsumer vertex(double x, double y, double z) {
         this.first.vertex(x, y, z);
         this.second.vertex(x, y, z);
         return this;
      }

      public VertexConsumer color(int red, int green, int blue, int alpha) {
         this.first.color(red, green, blue, alpha);
         this.second.color(red, green, blue, alpha);
         return this;
      }

      public VertexConsumer uv(float u, float v) {
         this.first.uv(u, v);
         this.second.uv(u, v);
         return this;
      }

      public VertexConsumer overlayCoords(int u, int v) {
         this.first.overlayCoords(u, v);
         this.second.overlayCoords(u, v);
         return this;
      }

      public VertexConsumer uv2(int u, int v) {
         this.first.uv2(u, v);
         this.second.uv2(u, v);
         return this;
      }

      public VertexConsumer normal(float x, float y, float z) {
         this.first.normal(x, y, z);
         this.second.normal(x, y, z);
         return this;
      }

      public void vertex(float x, float y, float z, float red, float green, float blue, float alpha, float texU, float texV, int overlayUV, int lightmapUV, float normalX, float normalY, float normalZ) {
         this.first.vertex(x, y, z, red, green, blue, alpha, texU, texV, overlayUV, lightmapUV, normalX, normalY, normalZ);
         this.second.vertex(x, y, z, red, green, blue, alpha, texU, texV, overlayUV, lightmapUV, normalX, normalY, normalZ);
      }

      public void endVertex() {
         this.first.endVertex();
         this.second.endVertex();
      }

      public void defaultColor(int defaultR, int defaultG, int defaultB, int defaultA) {
         this.first.defaultColor(defaultR, defaultG, defaultB, defaultA);
         this.second.defaultColor(defaultR, defaultG, defaultB, defaultA);
      }

      public void unsetDefaultColor() {
         this.first.unsetDefaultColor();
         this.second.unsetDefaultColor();
      }
   }

   @OnlyIn(Dist.CLIENT)
   static class Multiple implements VertexConsumer {
      private final VertexConsumer[] delegates;

      public Multiple(VertexConsumer[] delegates) {
         for(int i = 0; i < delegates.length; ++i) {
            for(int j = i + 1; j < delegates.length; ++j) {
               if (delegates[i] == delegates[j]) {
                  throw new IllegalArgumentException("Duplicate delegates");
               }
            }
         }

         this.delegates = delegates;
      }

      private void forEach(Consumer<VertexConsumer> consumer) {
         for(VertexConsumer vertexconsumer : this.delegates) {
            consumer.accept(vertexconsumer);
         }

      }

      public VertexConsumer vertex(double x, double y, double z) {
         this.forEach((p_167082_) -> {
            p_167082_.vertex(x, y, z);
         });
         return this;
      }

      public VertexConsumer color(int red, int green, int blue, int alpha) {
         this.forEach((p_167163_) -> {
            p_167163_.color(red, green, blue, alpha);
         });
         return this;
      }

      public VertexConsumer uv(float u, float v) {
         this.forEach((p_167125_) -> {
            p_167125_.uv(u, v);
         });
         return this;
      }

      public VertexConsumer overlayCoords(int u, int v) {
         this.forEach((p_167167_) -> {
            p_167167_.overlayCoords(u, v);
         });
         return this;
      }

      public VertexConsumer uv2(int u, int v) {
         this.forEach((p_167143_) -> {
            p_167143_.uv2(u, v);
         });
         return this;
      }

      public VertexConsumer normal(float x, float y, float z) {
         this.forEach((p_167121_) -> {
            p_167121_.normal(x, y, z);
         });
         return this;
      }

      public void vertex(float x, float y, float z, float red, float green, float blue, float alpha, float texU, float texV, int overlayUV, int lightmapUV, float normalX, float normalY, float normalZ) {
         this.forEach((p_167116_) -> {
            p_167116_.vertex(x, y, z, red, green, blue, alpha, texU, texV, overlayUV, lightmapUV, normalX, normalY, normalZ);
         });
      }

      public void endVertex() {
         this.forEach(VertexConsumer::endVertex);
      }

      public void defaultColor(int defaultR, int defaultG, int defaultB, int defaultA) {
         this.forEach((p_167139_) -> {
            p_167139_.defaultColor(defaultR, defaultG, defaultB, defaultA);
         });
      }

      public void unsetDefaultColor() {
         this.forEach(VertexConsumer::unsetDefaultColor);
      }
   }
}
