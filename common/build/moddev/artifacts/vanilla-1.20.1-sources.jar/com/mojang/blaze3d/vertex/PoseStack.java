package com.mojang.blaze3d.vertex;

import com.google.common.collect.Queues;
import java.util.Deque;
import net.minecraft.Util;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

@OnlyIn(Dist.CLIENT)
public class PoseStack {
   private final Deque<PoseStack.Pose> poseStack = Util.make(Queues.newArrayDeque(), (p_85848_) -> {
      Matrix4f matrix4f = new Matrix4f();
      Matrix3f matrix3f = new Matrix3f();
      p_85848_.add(new PoseStack.Pose(matrix4f, matrix3f));
   });

   public void translate(double x, double y, double z) {
      this.translate((float)x, (float)y, (float)z);
   }

   public void translate(float x, float y, float z) {
      PoseStack.Pose posestack$pose = this.poseStack.getLast();
      posestack$pose.pose.translate(x, y, z);
   }

   public void scale(float x, float y, float z) {
      PoseStack.Pose posestack$pose = this.poseStack.getLast();
      posestack$pose.pose.scale(x, y, z);
      if (x == y && y == z) {
         if (x > 0.0F) {
            return;
         }

         posestack$pose.normal.scale(-1.0F);
      }

      float f = 1.0F / x;
      float f1 = 1.0F / y;
      float f2 = 1.0F / z;
      float f3 = Mth.fastInvCubeRoot(f * f1 * f2);
      posestack$pose.normal.scale(f3 * f, f3 * f1, f3 * f2);
   }

   public void mulPose(Quaternionf quaternion) {
      PoseStack.Pose posestack$pose = this.poseStack.getLast();
      posestack$pose.pose.rotate(quaternion);
      posestack$pose.normal.rotate(quaternion);
   }

   public void rotateAround(Quaternionf quaternion, float x, float y, float z) {
      PoseStack.Pose posestack$pose = this.poseStack.getLast();
      posestack$pose.pose.rotateAround(quaternion, x, y, z);
      posestack$pose.normal.rotate(quaternion);
   }

   public void pushPose() {
      PoseStack.Pose posestack$pose = this.poseStack.getLast();
      this.poseStack.addLast(new PoseStack.Pose(new Matrix4f(posestack$pose.pose), new Matrix3f(posestack$pose.normal)));
   }

   public void popPose() {
      this.poseStack.removeLast();
   }

   public PoseStack.Pose last() {
      return this.poseStack.getLast();
   }

   public boolean clear() {
      return this.poseStack.size() == 1;
   }

   public void setIdentity() {
      PoseStack.Pose posestack$pose = this.poseStack.getLast();
      posestack$pose.pose.identity();
      posestack$pose.normal.identity();
   }

   public void mulPoseMatrix(Matrix4f matrix) {
      (this.poseStack.getLast()).pose.mul(matrix);
   }

   @OnlyIn(Dist.CLIENT)
   public static final class Pose {
      final Matrix4f pose;
      final Matrix3f normal;

      Pose(Matrix4f pose, Matrix3f normal) {
         this.pose = pose;
         this.normal = normal;
      }

      public Matrix4f pose() {
         return this.pose;
      }

      public Matrix3f normal() {
         return this.normal;
      }
   }
}
