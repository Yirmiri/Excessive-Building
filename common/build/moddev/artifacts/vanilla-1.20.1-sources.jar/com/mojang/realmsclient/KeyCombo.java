package com.mojang.realmsclient;

import java.util.Arrays;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class KeyCombo {
   private final char[] chars;
   private int matchIndex;
   private final Runnable onCompletion;

   public KeyCombo(char[] chars, Runnable onCompletion) {
      this.onCompletion = onCompletion;
      if (chars.length < 1) {
         throw new IllegalArgumentException("Must have at least one char");
      } else {
         this.chars = chars;
      }
   }

   public KeyCombo(char[] chars) {
      this(chars, () -> {
      });
   }

   public boolean keyPressed(char key) {
      if (key == this.chars[this.matchIndex++]) {
         if (this.matchIndex == this.chars.length) {
            this.reset();
            this.onCompletion.run();
            return true;
         }
      } else {
         this.reset();
      }

      return false;
   }

   public void reset() {
      this.matchIndex = 0;
   }

   public String toString() {
      return "KeyCombo{chars=" + Arrays.toString(this.chars) + ", matchIndex=" + this.matchIndex + "}";
   }
}
