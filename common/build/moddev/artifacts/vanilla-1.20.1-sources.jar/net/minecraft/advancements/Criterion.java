package net.minecraft.advancements;

import com.google.common.collect.Maps;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.advancements.critereon.DeserializationContext;
import net.minecraft.advancements.critereon.SerializationContext;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;

public class Criterion {
   @Nullable
   private final CriterionTriggerInstance trigger;

   public Criterion(CriterionTriggerInstance trigger) {
      this.trigger = trigger;
   }

   public Criterion() {
      this.trigger = null;
   }

   public void serializeToNetwork(FriendlyByteBuf buffer) {
   }

   public static Criterion criterionFromJson(JsonObject json, DeserializationContext context) {
      ResourceLocation resourcelocation = new ResourceLocation(GsonHelper.getAsString(json, "trigger"));
      CriterionTrigger<?> criteriontrigger = CriteriaTriggers.getCriterion(resourcelocation);
      if (criteriontrigger == null) {
         throw new JsonSyntaxException("Invalid criterion trigger: " + resourcelocation);
      } else {
         CriterionTriggerInstance criteriontriggerinstance = criteriontrigger.createInstance(GsonHelper.getAsJsonObject(json, "conditions", new JsonObject()), context);
         return new Criterion(criteriontriggerinstance);
      }
   }

   public static Criterion criterionFromNetwork(FriendlyByteBuf buffer) {
      return new Criterion();
   }

   public static Map<String, Criterion> criteriaFromJson(JsonObject json, DeserializationContext context) {
      Map<String, Criterion> map = Maps.newHashMap();

      for(Map.Entry<String, JsonElement> entry : json.entrySet()) {
         map.put(entry.getKey(), criterionFromJson(GsonHelper.convertToJsonObject(entry.getValue(), "criterion"), context));
      }

      return map;
   }

   public static Map<String, Criterion> criteriaFromNetwork(FriendlyByteBuf buffer) {
      return buffer.readMap(FriendlyByteBuf::readUtf, Criterion::criterionFromNetwork);
   }

   public static void serializeToNetwork(Map<String, Criterion> criteria, FriendlyByteBuf buffer) {
      buffer.writeMap(criteria, FriendlyByteBuf::writeUtf, (p_145258_, p_145259_) -> {
         p_145259_.serializeToNetwork(p_145258_);
      });
   }

   @Nullable
   public CriterionTriggerInstance getTrigger() {
      return this.trigger;
   }

   public JsonElement serializeToJson() {
      if (this.trigger == null) {
         throw new JsonSyntaxException("Missing trigger");
      } else {
         JsonObject jsonobject = new JsonObject();
         jsonobject.addProperty("trigger", this.trigger.getCriterion().toString());
         JsonObject jsonobject1 = this.trigger.serializeToJson(SerializationContext.INSTANCE);
         if (jsonobject1.size() != 0) {
            jsonobject.add("conditions", jsonobject1);
         }

         return jsonobject;
      }
   }
}
