package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;

public class PlayerInteractTrigger extends SimpleCriterionTrigger<PlayerInteractTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("player_interacted_with_entity");

   public ResourceLocation getId() {
      return ID;
   }

   protected PlayerInteractTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      ItemPredicate itempredicate = ItemPredicate.fromJson(json.get("item"));
      ContextAwarePredicate contextawarepredicate = EntityPredicate.fromJson(json, "entity", deserializationContext);
      return new PlayerInteractTrigger.TriggerInstance(predicate, itempredicate, contextawarepredicate);
   }

   public void trigger(ServerPlayer player, ItemStack item, Entity entity) {
      LootContext lootcontext = EntityPredicate.createContext(player, entity);
      this.trigger(player, (p_61501_) -> {
         return p_61501_.matches(item, lootcontext);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final ItemPredicate item;
      private final ContextAwarePredicate entity;

      public TriggerInstance(ContextAwarePredicate player, ItemPredicate item, ContextAwarePredicate entity) {
         super(PlayerInteractTrigger.ID, player);
         this.item = item;
         this.entity = entity;
      }

      public static PlayerInteractTrigger.TriggerInstance itemUsedOnEntity(ContextAwarePredicate player, ItemPredicate.Builder item, ContextAwarePredicate entity) {
         return new PlayerInteractTrigger.TriggerInstance(player, item.build(), entity);
      }

      public static PlayerInteractTrigger.TriggerInstance itemUsedOnEntity(ItemPredicate.Builder item, ContextAwarePredicate entity) {
         return itemUsedOnEntity(ContextAwarePredicate.ANY, item, entity);
      }

      public boolean matches(ItemStack item, LootContext lootContext) {
         return !this.item.matches(item) ? false : this.entity.matches(lootContext);
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.add("item", this.item.serializeToJson());
         jsonobject.add("entity", this.entity.toJson(conditions));
         return jsonobject;
      }
   }
}
