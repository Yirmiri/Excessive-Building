package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;

public class ShotCrossbowTrigger extends SimpleCriterionTrigger<ShotCrossbowTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("shot_crossbow");

   public ResourceLocation getId() {
      return ID;
   }

   public ShotCrossbowTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      ItemPredicate itempredicate = ItemPredicate.fromJson(json.get("item"));
      return new ShotCrossbowTrigger.TriggerInstance(predicate, itempredicate);
   }

   public void trigger(ServerPlayer shooter, ItemStack stack) {
      this.trigger(shooter, (p_65467_) -> {
         return p_65467_.matches(stack);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final ItemPredicate item;

      public TriggerInstance(ContextAwarePredicate player, ItemPredicate item) {
         super(ShotCrossbowTrigger.ID, player);
         this.item = item;
      }

      public static ShotCrossbowTrigger.TriggerInstance shotCrossbow(ItemPredicate item) {
         return new ShotCrossbowTrigger.TriggerInstance(ContextAwarePredicate.ANY, item);
      }

      public static ShotCrossbowTrigger.TriggerInstance shotCrossbow(ItemLike item) {
         return new ShotCrossbowTrigger.TriggerInstance(ContextAwarePredicate.ANY, ItemPredicate.Builder.item().of(item).build());
      }

      public boolean matches(ItemStack item) {
         return this.item.matches(item);
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.add("item", this.item.serializeToJson());
         return jsonobject;
      }
   }
}
