package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

public class DistanceTrigger extends SimpleCriterionTrigger<DistanceTrigger.TriggerInstance> {
   final ResourceLocation id;

   public DistanceTrigger(ResourceLocation id) {
      this.id = id;
   }

   public ResourceLocation getId() {
      return this.id;
   }

   public DistanceTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      LocationPredicate locationpredicate = LocationPredicate.fromJson(json.get("start_position"));
      DistancePredicate distancepredicate = DistancePredicate.fromJson(json.get("distance"));
      return new DistanceTrigger.TriggerInstance(this.id, predicate, locationpredicate, distancepredicate);
   }

   public void trigger(ServerPlayer player, Vec3 position) {
      Vec3 vec3 = player.position();
      this.trigger(player, (p_284572_) -> {
         return p_284572_.matches(player.serverLevel(), position, vec3);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final LocationPredicate startPosition;
      private final DistancePredicate distance;

      public TriggerInstance(ResourceLocation criterion, ContextAwarePredicate player, LocationPredicate startPosition, DistancePredicate distance) {
         super(criterion, player);
         this.startPosition = startPosition;
         this.distance = distance;
      }

      public static DistanceTrigger.TriggerInstance fallFromHeight(EntityPredicate.Builder player, DistancePredicate distance, LocationPredicate startPosition) {
         return new DistanceTrigger.TriggerInstance(CriteriaTriggers.FALL_FROM_HEIGHT.id, EntityPredicate.wrap(player.build()), startPosition, distance);
      }

      public static DistanceTrigger.TriggerInstance rideEntityInLava(EntityPredicate.Builder player, DistancePredicate distance) {
         return new DistanceTrigger.TriggerInstance(CriteriaTriggers.RIDE_ENTITY_IN_LAVA_TRIGGER.id, EntityPredicate.wrap(player.build()), LocationPredicate.ANY, distance);
      }

      public static DistanceTrigger.TriggerInstance travelledThroughNether(DistancePredicate distance) {
         return new DistanceTrigger.TriggerInstance(CriteriaTriggers.NETHER_TRAVEL.id, ContextAwarePredicate.ANY, LocationPredicate.ANY, distance);
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.add("start_position", this.startPosition.serializeToJson());
         jsonobject.add("distance", this.distance.serializeToJson());
         return jsonobject;
      }

      public boolean matches(ServerLevel level, Vec3 startPosition, Vec3 currentPosition) {
         if (!this.startPosition.matches(level, startPosition.x, startPosition.y, startPosition.z)) {
            return false;
         } else {
            return this.distance.matches(startPosition.x, startPosition.y, startPosition.z, currentPosition.x, currentPosition.y, currentPosition.z);
         }
      }
   }
}
