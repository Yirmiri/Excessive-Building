package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import java.util.Collection;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.projectile.FishingHook;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;

public class FishingRodHookedTrigger extends SimpleCriterionTrigger<FishingRodHookedTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("fishing_rod_hooked");

   public ResourceLocation getId() {
      return ID;
   }

   public FishingRodHookedTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      ItemPredicate itempredicate = ItemPredicate.fromJson(json.get("rod"));
      ContextAwarePredicate contextawarepredicate = EntityPredicate.fromJson(json, "entity", deserializationContext);
      ItemPredicate itempredicate1 = ItemPredicate.fromJson(json.get("item"));
      return new FishingRodHookedTrigger.TriggerInstance(predicate, itempredicate, contextawarepredicate, itempredicate1);
   }

   public void trigger(ServerPlayer player, ItemStack rod, FishingHook entity, Collection<ItemStack> stacks) {
      LootContext lootcontext = EntityPredicate.createContext(player, (Entity)(entity.getHookedIn() != null ? entity.getHookedIn() : entity));
      this.trigger(player, (p_40425_) -> {
         return p_40425_.matches(rod, lootcontext, stacks);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final ItemPredicate rod;
      private final ContextAwarePredicate entity;
      private final ItemPredicate item;

      public TriggerInstance(ContextAwarePredicate player, ItemPredicate rod, ContextAwarePredicate entity, ItemPredicate item) {
         super(FishingRodHookedTrigger.ID, player);
         this.rod = rod;
         this.entity = entity;
         this.item = item;
      }

      public static FishingRodHookedTrigger.TriggerInstance fishedItem(ItemPredicate rod, EntityPredicate bobber, ItemPredicate item) {
         return new FishingRodHookedTrigger.TriggerInstance(ContextAwarePredicate.ANY, rod, EntityPredicate.wrap(bobber), item);
      }

      public boolean matches(ItemStack rod, LootContext context, Collection<ItemStack> stacks) {
         if (!this.rod.matches(rod)) {
            return false;
         } else if (!this.entity.matches(context)) {
            return false;
         } else {
            if (this.item != ItemPredicate.ANY) {
               boolean flag = false;
               Entity entity = context.getParamOrNull(LootContextParams.THIS_ENTITY);
               if (entity instanceof ItemEntity) {
                  ItemEntity itementity = (ItemEntity)entity;
                  if (this.item.matches(itementity.getItem())) {
                     flag = true;
                  }
               }

               for(ItemStack itemstack : stacks) {
                  if (this.item.matches(itemstack)) {
                     flag = true;
                     break;
                  }
               }

               if (!flag) {
                  return false;
               }
            }

            return true;
         }
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.add("rod", this.rod.serializeToJson());
         jsonobject.add("entity", this.entity.toJson(conditions));
         jsonobject.add("item", this.item.serializeToJson());
         return jsonobject;
      }
   }
}
