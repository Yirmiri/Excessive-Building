package net.minecraft.advancements;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.Arrays;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.advancements.critereon.DeserializationContext;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentUtils;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import org.apache.commons.lang3.ArrayUtils;

public class Advancement {
   @Nullable
   private final Advancement parent;
   @Nullable
   private final DisplayInfo display;
   private final AdvancementRewards rewards;
   private final ResourceLocation id;
   private final Map<String, Criterion> criteria;
   private final String[][] requirements;
   private final Set<Advancement> children = Sets.newLinkedHashSet();
   private final Component chatComponent;
   private final boolean sendsTelemetryEvent;

   public Advancement(ResourceLocation id, @Nullable Advancement parent, @Nullable DisplayInfo display, AdvancementRewards rewards, Map<String, Criterion> criteria, String[][] requirements, boolean sendsTelemetryEvent) {
      this.id = id;
      this.display = display;
      this.criteria = ImmutableMap.copyOf(criteria);
      this.parent = parent;
      this.rewards = rewards;
      this.requirements = requirements;
      this.sendsTelemetryEvent = sendsTelemetryEvent;
      if (parent != null) {
         parent.addChild(this);
      }

      if (display == null) {
         this.chatComponent = Component.literal(id.toString());
      } else {
         Component component = display.getTitle();
         ChatFormatting chatformatting = display.getFrame().getChatColor();
         Component component1 = ComponentUtils.mergeStyles(component.copy(), Style.EMPTY.withColor(chatformatting)).append("\n").append(display.getDescription());
         Component component2 = component.copy().withStyle((p_138316_) -> {
            return p_138316_.withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, component1));
         });
         this.chatComponent = ComponentUtils.wrapInSquareBrackets(component2).withStyle(chatformatting);
      }

   }

   public Advancement.Builder deconstruct() {
      return new Advancement.Builder(this.parent == null ? null : this.parent.getId(), this.display, this.rewards, this.criteria, this.requirements, this.sendsTelemetryEvent);
   }

   @Nullable
   public Advancement getParent() {
      return this.parent;
   }

   public Advancement getRoot() {
      return getRoot(this);
   }

   public static Advancement getRoot(Advancement p_advancement) {
      Advancement advancement = p_advancement;

      while(true) {
         Advancement advancement1 = advancement.getParent();
         if (advancement1 == null) {
            return advancement;
         }

         advancement = advancement1;
      }
   }

   @Nullable
   public DisplayInfo getDisplay() {
      return this.display;
   }

   public boolean sendsTelemetryEvent() {
      return this.sendsTelemetryEvent;
   }

   public AdvancementRewards getRewards() {
      return this.rewards;
   }

   public String toString() {
      return "SimpleAdvancement{id=" + this.getId() + ", parent=" + (this.parent == null ? "null" : this.parent.getId()) + ", display=" + this.display + ", rewards=" + this.rewards + ", criteria=" + this.criteria + ", requirements=" + Arrays.deepToString(this.requirements) + ", sendsTelemetryEvent=" + this.sendsTelemetryEvent + "}";
   }

   public Iterable<Advancement> getChildren() {
      return this.children;
   }

   public Map<String, Criterion> getCriteria() {
      return this.criteria;
   }

   public int getMaxCriteraRequired() {
      return this.requirements.length;
   }

   /**
    * Add the provided {@code child} as a child of this advancement.
    */
   public void addChild(Advancement child) {
      this.children.add(child);
   }

   public ResourceLocation getId() {
      return this.id;
   }

   public boolean equals(Object other) {
      if (this == other) {
         return true;
      } else if (!(other instanceof Advancement)) {
         return false;
      } else {
         Advancement advancement = (Advancement)other;
         return this.id.equals(advancement.id);
      }
   }

   public int hashCode() {
      return this.id.hashCode();
   }

   public String[][] getRequirements() {
      return this.requirements;
   }

   public Component getChatComponent() {
      return this.chatComponent;
   }

   public static class Builder {
      @Nullable
      private ResourceLocation parentId;
      @Nullable
      private Advancement parent;
      @Nullable
      private DisplayInfo display;
      private AdvancementRewards rewards = AdvancementRewards.EMPTY;
      private Map<String, Criterion> criteria = Maps.newLinkedHashMap();
      @Nullable
      private String[][] requirements;
      private RequirementsStrategy requirementsStrategy = RequirementsStrategy.AND;
      private final boolean sendsTelemetryEvent;

      Builder(@Nullable ResourceLocation parentId, @Nullable DisplayInfo display, AdvancementRewards rewards, Map<String, Criterion> criteria, String[][] requirements, boolean sendsTelemetryEvent) {
         this.parentId = parentId;
         this.display = display;
         this.rewards = rewards;
         this.criteria = criteria;
         this.requirements = requirements;
         this.sendsTelemetryEvent = sendsTelemetryEvent;
      }

      private Builder(boolean sendsTelemetryEvent) {
         this.sendsTelemetryEvent = sendsTelemetryEvent;
      }

      public static Advancement.Builder advancement() {
         return new Advancement.Builder(true);
      }

      public static Advancement.Builder recipeAdvancement() {
         return new Advancement.Builder(false);
      }

      public Advancement.Builder parent(Advancement parent) {
         this.parent = parent;
         return this;
      }

      public Advancement.Builder parent(ResourceLocation parentId) {
         this.parentId = parentId;
         return this;
      }

      public Advancement.Builder display(ItemStack stack, Component title, Component description, @Nullable ResourceLocation background, FrameType frame, boolean showToast, boolean announceToChat, boolean hidden) {
         return this.display(new DisplayInfo(stack, title, description, background, frame, showToast, announceToChat, hidden));
      }

      public Advancement.Builder display(ItemLike item, Component title, Component description, @Nullable ResourceLocation background, FrameType frame, boolean showToast, boolean announceToChat, boolean hidden) {
         return this.display(new DisplayInfo(new ItemStack(item.asItem()), title, description, background, frame, showToast, announceToChat, hidden));
      }

      public Advancement.Builder display(DisplayInfo display) {
         this.display = display;
         return this;
      }

      public Advancement.Builder rewards(AdvancementRewards.Builder rewardsBuilder) {
         return this.rewards(rewardsBuilder.build());
      }

      public Advancement.Builder rewards(AdvancementRewards rewards) {
         this.rewards = rewards;
         return this;
      }

      public Advancement.Builder addCriterion(String key, CriterionTriggerInstance criterion) {
         return this.addCriterion(key, new Criterion(criterion));
      }

      public Advancement.Builder addCriterion(String key, Criterion criterion) {
         if (this.criteria.containsKey(key)) {
            throw new IllegalArgumentException("Duplicate criterion " + key);
         } else {
            this.criteria.put(key, criterion);
            return this;
         }
      }

      public Advancement.Builder requirements(RequirementsStrategy strategy) {
         this.requirementsStrategy = strategy;
         return this;
      }

      public Advancement.Builder requirements(String[][] requirements) {
         this.requirements = requirements;
         return this;
      }

      /**
       * Tries to resolve the parent of this advancement, if possible. Returns {@code true} on success.
       */
      public boolean canBuild(Function<ResourceLocation, Advancement> parentLookup) {
         if (this.parentId == null) {
            return true;
         } else {
            if (this.parent == null) {
               this.parent = parentLookup.apply(this.parentId);
            }

            return this.parent != null;
         }
      }

      public Advancement build(ResourceLocation id) {
         if (!this.canBuild((p_138407_) -> {
            return null;
         })) {
            throw new IllegalStateException("Tried to build incomplete advancement!");
         } else {
            if (this.requirements == null) {
               this.requirements = this.requirementsStrategy.createRequirements(this.criteria.keySet());
            }

            return new Advancement(id, this.parent, this.display, this.rewards, this.criteria, this.requirements, this.sendsTelemetryEvent);
         }
      }

      public Advancement save(Consumer<Advancement> consumer, String id) {
         Advancement advancement = this.build(new ResourceLocation(id));
         consumer.accept(advancement);
         return advancement;
      }

      public JsonObject serializeToJson() {
         if (this.requirements == null) {
            this.requirements = this.requirementsStrategy.createRequirements(this.criteria.keySet());
         }

         JsonObject jsonobject = new JsonObject();
         if (this.parent != null) {
            jsonobject.addProperty("parent", this.parent.getId().toString());
         } else if (this.parentId != null) {
            jsonobject.addProperty("parent", this.parentId.toString());
         }

         if (this.display != null) {
            jsonobject.add("display", this.display.serializeToJson());
         }

         jsonobject.add("rewards", this.rewards.serializeToJson());
         JsonObject jsonobject1 = new JsonObject();

         for(Map.Entry<String, Criterion> entry : this.criteria.entrySet()) {
            jsonobject1.add(entry.getKey(), entry.getValue().serializeToJson());
         }

         jsonobject.add("criteria", jsonobject1);
         JsonArray jsonarray1 = new JsonArray();

         for(String[] astring : this.requirements) {
            JsonArray jsonarray = new JsonArray();

            for(String s : astring) {
               jsonarray.add(s);
            }

            jsonarray1.add(jsonarray);
         }

         jsonobject.add("requirements", jsonarray1);
         jsonobject.addProperty("sends_telemetry_event", this.sendsTelemetryEvent);
         return jsonobject;
      }

      public void serializeToNetwork(FriendlyByteBuf buffer) {
         if (this.requirements == null) {
            this.requirements = this.requirementsStrategy.createRequirements(this.criteria.keySet());
         }

         buffer.writeNullable(this.parentId, FriendlyByteBuf::writeResourceLocation);
         buffer.writeNullable(this.display, (p_214831_, p_214832_) -> {
            p_214832_.serializeToNetwork(p_214831_);
         });
         Criterion.serializeToNetwork(this.criteria, buffer);
         buffer.writeVarInt(this.requirements.length);

         for(String[] astring : this.requirements) {
            buffer.writeVarInt(astring.length);

            for(String s : astring) {
               buffer.writeUtf(s);
            }
         }

         buffer.writeBoolean(this.sendsTelemetryEvent);
      }

      public String toString() {
         return "Task Advancement{parentId=" + this.parentId + ", display=" + this.display + ", rewards=" + this.rewards + ", criteria=" + this.criteria + ", requirements=" + Arrays.deepToString(this.requirements) + ", sends_telemetry_event=" + this.sendsTelemetryEvent + "}";
      }

      public static Advancement.Builder fromJson(JsonObject json, DeserializationContext context) {
         ResourceLocation resourcelocation = json.has("parent") ? new ResourceLocation(GsonHelper.getAsString(json, "parent")) : null;
         DisplayInfo displayinfo = json.has("display") ? DisplayInfo.fromJson(GsonHelper.getAsJsonObject(json, "display")) : null;
         AdvancementRewards advancementrewards = json.has("rewards") ? AdvancementRewards.deserialize(GsonHelper.getAsJsonObject(json, "rewards")) : AdvancementRewards.EMPTY;
         Map<String, Criterion> map = Criterion.criteriaFromJson(GsonHelper.getAsJsonObject(json, "criteria"), context);
         if (map.isEmpty()) {
            throw new JsonSyntaxException("Advancement criteria cannot be empty");
         } else {
            JsonArray jsonarray = GsonHelper.getAsJsonArray(json, "requirements", new JsonArray());
            String[][] astring = new String[jsonarray.size()][];

            for(int i = 0; i < jsonarray.size(); ++i) {
               JsonArray jsonarray1 = GsonHelper.convertToJsonArray(jsonarray.get(i), "requirements[" + i + "]");
               astring[i] = new String[jsonarray1.size()];

               for(int j = 0; j < jsonarray1.size(); ++j) {
                  astring[i][j] = GsonHelper.convertToString(jsonarray1.get(j), "requirements[" + i + "][" + j + "]");
               }
            }

            if (astring.length == 0) {
               astring = new String[map.size()][];
               int k = 0;

               for(String s2 : map.keySet()) {
                  astring[k++] = new String[]{s2};
               }
            }

            for(String[] astring1 : astring) {
               if (astring1.length == 0 && map.isEmpty()) {
                  throw new JsonSyntaxException("Requirement entry cannot be empty");
               }

               for(String s : astring1) {
                  if (!map.containsKey(s)) {
                     throw new JsonSyntaxException("Unknown required criterion '" + s + "'");
                  }
               }
            }

            for(String s1 : map.keySet()) {
               boolean flag1 = false;

               for(String[] astring2 : astring) {
                  if (ArrayUtils.contains(astring2, s1)) {
                     flag1 = true;
                     break;
                  }
               }

               if (!flag1) {
                  throw new JsonSyntaxException("Criterion '" + s1 + "' isn't a requirement for completion. This isn't supported behaviour, all criteria must be required.");
               }
            }

            boolean flag = GsonHelper.getAsBoolean(json, "sends_telemetry_event", false);
            return new Advancement.Builder(resourcelocation, displayinfo, advancementrewards, map, astring, flag);
         }
      }

      public static Advancement.Builder fromNetwork(FriendlyByteBuf buffer) {
         ResourceLocation resourcelocation = buffer.readNullable(FriendlyByteBuf::readResourceLocation);
         DisplayInfo displayinfo = buffer.readNullable(DisplayInfo::fromNetwork);
         Map<String, Criterion> map = Criterion.criteriaFromNetwork(buffer);
         String[][] astring = new String[buffer.readVarInt()][];

         for(int i = 0; i < astring.length; ++i) {
            astring[i] = new String[buffer.readVarInt()];

            for(int j = 0; j < astring[i].length; ++j) {
               astring[i][j] = buffer.readUtf();
            }
         }

         boolean flag = buffer.readBoolean();
         return new Advancement.Builder(resourcelocation, displayinfo, AdvancementRewards.EMPTY, map, astring, flag);
      }

      public Map<String, Criterion> getCriteria() {
         return this.criteria;
      }
   }
}
