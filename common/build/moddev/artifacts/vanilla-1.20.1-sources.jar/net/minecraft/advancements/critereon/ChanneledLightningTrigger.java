package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.storage.loot.LootContext;

public class ChanneledLightningTrigger extends SimpleCriterionTrigger<ChanneledLightningTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("channeled_lightning");

   public ResourceLocation getId() {
      return ID;
   }

   public ChanneledLightningTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      ContextAwarePredicate[] acontextawarepredicate = EntityPredicate.fromJsonArray(json, "victims", deserializationContext);
      return new ChanneledLightningTrigger.TriggerInstance(predicate, acontextawarepredicate);
   }

   public void trigger(ServerPlayer player, Collection<? extends Entity> entityTriggered) {
      List<LootContext> list = entityTriggered.stream().map((p_21720_) -> {
         return EntityPredicate.createContext(player, p_21720_);
      }).collect(Collectors.toList());
      this.trigger(player, (p_21730_) -> {
         return p_21730_.matches(list);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final ContextAwarePredicate[] victims;

      public TriggerInstance(ContextAwarePredicate player, ContextAwarePredicate[] victims) {
         super(ChanneledLightningTrigger.ID, player);
         this.victims = victims;
      }

      public static ChanneledLightningTrigger.TriggerInstance channeledLightning(EntityPredicate... victims) {
         return new ChanneledLightningTrigger.TriggerInstance(ContextAwarePredicate.ANY, Stream.of(victims).map(EntityPredicate::wrap).toArray((p_286116_) -> {
            return new ContextAwarePredicate[p_286116_];
         }));
      }

      public boolean matches(Collection<? extends LootContext> victims) {
         for(ContextAwarePredicate contextawarepredicate : this.victims) {
            boolean flag = false;

            for(LootContext lootcontext : victims) {
               if (contextawarepredicate.matches(lootcontext)) {
                  flag = true;
                  break;
               }
            }

            if (!flag) {
               return false;
            }
         }

         return true;
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.add("victims", ContextAwarePredicate.toJson(this.victims, conditions));
         return jsonobject;
      }
   }
}
