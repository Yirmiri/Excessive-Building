package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import javax.annotation.Nullable;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.storage.loot.LootContext;

public class EffectsChangedTrigger extends SimpleCriterionTrigger<EffectsChangedTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("effects_changed");

   public ResourceLocation getId() {
      return ID;
   }

   public EffectsChangedTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      MobEffectsPredicate mobeffectspredicate = MobEffectsPredicate.fromJson(json.get("effects"));
      ContextAwarePredicate contextawarepredicate = EntityPredicate.fromJson(json, "source", deserializationContext);
      return new EffectsChangedTrigger.TriggerInstance(predicate, mobeffectspredicate, contextawarepredicate);
   }

   public void trigger(ServerPlayer player, @Nullable Entity source) {
      LootContext lootcontext = source != null ? EntityPredicate.createContext(player, source) : null;
      this.trigger(player, (p_149268_) -> {
         return p_149268_.matches(player, lootcontext);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final MobEffectsPredicate effects;
      private final ContextAwarePredicate source;

      public TriggerInstance(ContextAwarePredicate player, MobEffectsPredicate effects, ContextAwarePredicate source) {
         super(EffectsChangedTrigger.ID, player);
         this.effects = effects;
         this.source = source;
      }

      public static EffectsChangedTrigger.TriggerInstance hasEffects(MobEffectsPredicate effects) {
         return new EffectsChangedTrigger.TriggerInstance(ContextAwarePredicate.ANY, effects, ContextAwarePredicate.ANY);
      }

      public static EffectsChangedTrigger.TriggerInstance gotEffectsFrom(EntityPredicate source) {
         return new EffectsChangedTrigger.TriggerInstance(ContextAwarePredicate.ANY, MobEffectsPredicate.ANY, EntityPredicate.wrap(source));
      }

      public boolean matches(ServerPlayer player, @Nullable LootContext lootContext) {
         if (!this.effects.matches(player)) {
            return false;
         } else {
            return this.source == ContextAwarePredicate.ANY || lootContext != null && this.source.matches(lootContext);
         }
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.add("effects", this.effects.serializeToJson());
         jsonobject.add("source", this.source.toJson(conditions));
         return jsonobject;
      }
   }
}
