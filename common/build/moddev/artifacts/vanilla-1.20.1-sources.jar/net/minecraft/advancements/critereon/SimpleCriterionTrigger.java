package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonObject;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import net.minecraft.advancements.CriterionTrigger;
import net.minecraft.server.PlayerAdvancements;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.storage.loot.LootContext;

public abstract class SimpleCriterionTrigger<T extends AbstractCriterionTriggerInstance> implements CriterionTrigger<T> {
   private final Map<PlayerAdvancements, Set<CriterionTrigger.Listener<T>>> players = Maps.newIdentityHashMap();

   public final void addPlayerListener(PlayerAdvancements playerAdvancements, CriterionTrigger.Listener<T> listener) {
      this.players.computeIfAbsent(playerAdvancements, (p_66252_) -> {
         return Sets.newHashSet();
      }).add(listener);
   }

   public final void removePlayerListener(PlayerAdvancements playerAdvancements, CriterionTrigger.Listener<T> listener) {
      Set<CriterionTrigger.Listener<T>> set = this.players.get(playerAdvancements);
      if (set != null) {
         set.remove(listener);
         if (set.isEmpty()) {
            this.players.remove(playerAdvancements);
         }
      }

   }

   public final void removePlayerListeners(PlayerAdvancements playerAdvancements) {
      this.players.remove(playerAdvancements);
   }

   protected abstract T createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext);

   public final T createInstance(JsonObject object, DeserializationContext conditions) {
      ContextAwarePredicate contextawarepredicate = EntityPredicate.fromJson(object, "player", conditions);
      return this.createInstance(object, contextawarepredicate, conditions);
   }

   protected void trigger(ServerPlayer player, Predicate<T> testTrigger) {
      PlayerAdvancements playeradvancements = player.getAdvancements();
      Set<CriterionTrigger.Listener<T>> set = this.players.get(playeradvancements);
      if (set != null && !set.isEmpty()) {
         LootContext lootcontext = EntityPredicate.createContext(player, player);
         List<CriterionTrigger.Listener<T>> list = null;

         for(CriterionTrigger.Listener<T> listener : set) {
            T t = listener.getTriggerInstance();
            if (testTrigger.test(t) && t.getPlayerPredicate().matches(lootcontext)) {
               if (list == null) {
                  list = Lists.newArrayList();
               }

               list.add(listener);
            }
         }

         if (list != null) {
            for(CriterionTrigger.Listener<T> listener1 : list) {
               listener1.run(playeradvancements);
            }
         }

      }
   }
}
