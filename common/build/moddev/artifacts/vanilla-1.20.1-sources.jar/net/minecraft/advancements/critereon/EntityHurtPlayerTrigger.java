package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;

public class EntityHurtPlayerTrigger extends SimpleCriterionTrigger<EntityHurtPlayerTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("entity_hurt_player");

   public ResourceLocation getId() {
      return ID;
   }

   public EntityHurtPlayerTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      DamagePredicate damagepredicate = DamagePredicate.fromJson(json.get("damage"));
      return new EntityHurtPlayerTrigger.TriggerInstance(predicate, damagepredicate);
   }

   public void trigger(ServerPlayer player, DamageSource source, float dealtDamage, float takenDamage, boolean blocked) {
      this.trigger(player, (p_35186_) -> {
         return p_35186_.matches(player, source, dealtDamage, takenDamage, blocked);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final DamagePredicate damage;

      public TriggerInstance(ContextAwarePredicate player, DamagePredicate damage) {
         super(EntityHurtPlayerTrigger.ID, player);
         this.damage = damage;
      }

      public static EntityHurtPlayerTrigger.TriggerInstance entityHurtPlayer() {
         return new EntityHurtPlayerTrigger.TriggerInstance(ContextAwarePredicate.ANY, DamagePredicate.ANY);
      }

      public static EntityHurtPlayerTrigger.TriggerInstance entityHurtPlayer(DamagePredicate damage) {
         return new EntityHurtPlayerTrigger.TriggerInstance(ContextAwarePredicate.ANY, damage);
      }

      public static EntityHurtPlayerTrigger.TriggerInstance entityHurtPlayer(DamagePredicate.Builder damageConditionBuilder) {
         return new EntityHurtPlayerTrigger.TriggerInstance(ContextAwarePredicate.ANY, damageConditionBuilder.build());
      }

      public boolean matches(ServerPlayer player, DamageSource source, float dealtDamage, float takenDamage, boolean blocked) {
         return this.damage.matches(player, source, dealtDamage, takenDamage, blocked);
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.add("damage", this.damage.serializeToJson());
         return jsonobject;
      }
   }
}
