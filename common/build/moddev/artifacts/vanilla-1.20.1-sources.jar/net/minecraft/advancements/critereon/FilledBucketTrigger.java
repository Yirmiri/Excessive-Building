package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

public class FilledBucketTrigger extends SimpleCriterionTrigger<FilledBucketTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("filled_bucket");

   public ResourceLocation getId() {
      return ID;
   }

   public FilledBucketTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      ItemPredicate itempredicate = ItemPredicate.fromJson(json.get("item"));
      return new FilledBucketTrigger.TriggerInstance(predicate, itempredicate);
   }

   public void trigger(ServerPlayer player, ItemStack stack) {
      this.trigger(player, (p_38777_) -> {
         return p_38777_.matches(stack);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final ItemPredicate item;

      public TriggerInstance(ContextAwarePredicate player, ItemPredicate item) {
         super(FilledBucketTrigger.ID, player);
         this.item = item;
      }

      public static FilledBucketTrigger.TriggerInstance filledBucket(ItemPredicate item) {
         return new FilledBucketTrigger.TriggerInstance(ContextAwarePredicate.ANY, item);
      }

      public boolean matches(ItemStack stack) {
         return this.item.matches(stack);
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.add("item", this.item.serializeToJson());
         return jsonobject;
      }
   }
}
