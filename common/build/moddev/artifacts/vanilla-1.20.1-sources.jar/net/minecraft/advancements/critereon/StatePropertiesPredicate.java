package net.minecraft.advancements.critereon;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;
import javax.annotation.Nullable;
import net.minecraft.util.GsonHelper;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.StateHolder;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.FluidState;

public class StatePropertiesPredicate {
   public static final StatePropertiesPredicate ANY = new StatePropertiesPredicate(ImmutableList.of());
   private final List<StatePropertiesPredicate.PropertyMatcher> properties;

   private static StatePropertiesPredicate.PropertyMatcher fromJson(String name, JsonElement json) {
      if (json.isJsonPrimitive()) {
         String s2 = json.getAsString();
         return new StatePropertiesPredicate.ExactPropertyMatcher(name, s2);
      } else {
         JsonObject jsonobject = GsonHelper.convertToJsonObject(json, "value");
         String s = jsonobject.has("min") ? getStringOrNull(jsonobject.get("min")) : null;
         String s1 = jsonobject.has("max") ? getStringOrNull(jsonobject.get("max")) : null;
         return (StatePropertiesPredicate.PropertyMatcher)(s != null && s.equals(s1) ? new StatePropertiesPredicate.ExactPropertyMatcher(name, s) : new StatePropertiesPredicate.RangedPropertyMatcher(name, s, s1));
      }
   }

   @Nullable
   private static String getStringOrNull(JsonElement json) {
      return json.isJsonNull() ? null : json.getAsString();
   }

   StatePropertiesPredicate(List<StatePropertiesPredicate.PropertyMatcher> properties) {
      this.properties = ImmutableList.copyOf(properties);
   }

   public <S extends StateHolder<?, S>> boolean matches(StateDefinition<?, S> properties, S targetProperty) {
      for(StatePropertiesPredicate.PropertyMatcher statepropertiespredicate$propertymatcher : this.properties) {
         if (!statepropertiespredicate$propertymatcher.match(properties, targetProperty)) {
            return false;
         }
      }

      return true;
   }

   public boolean matches(BlockState state) {
      return this.matches(state.getBlock().getStateDefinition(), state);
   }

   public boolean matches(FluidState state) {
      return this.matches(state.getType().getStateDefinition(), state);
   }

   public void checkState(StateDefinition<?, ?> properties, Consumer<String> propertyConsumer) {
      this.properties.forEach((p_67678_) -> {
         p_67678_.checkState(properties, propertyConsumer);
      });
   }

   public static StatePropertiesPredicate fromJson(@Nullable JsonElement json) {
      if (json != null && !json.isJsonNull()) {
         JsonObject jsonobject = GsonHelper.convertToJsonObject(json, "properties");
         List<StatePropertiesPredicate.PropertyMatcher> list = Lists.newArrayList();

         for(Map.Entry<String, JsonElement> entry : jsonobject.entrySet()) {
            list.add(fromJson(entry.getKey(), entry.getValue()));
         }

         return new StatePropertiesPredicate(list);
      } else {
         return ANY;
      }
   }

   public JsonElement serializeToJson() {
      if (this == ANY) {
         return JsonNull.INSTANCE;
      } else {
         JsonObject jsonobject = new JsonObject();
         if (!this.properties.isEmpty()) {
            this.properties.forEach((p_67683_) -> {
               jsonobject.add(p_67683_.getName(), p_67683_.toJson());
            });
         }

         return jsonobject;
      }
   }

   public static class Builder {
      private final List<StatePropertiesPredicate.PropertyMatcher> matchers = Lists.newArrayList();

      private Builder() {
      }

      public static StatePropertiesPredicate.Builder properties() {
         return new StatePropertiesPredicate.Builder();
      }

      public StatePropertiesPredicate.Builder hasProperty(Property<?> property, String value) {
         this.matchers.add(new StatePropertiesPredicate.ExactPropertyMatcher(property.getName(), value));
         return this;
      }

      public StatePropertiesPredicate.Builder hasProperty(Property<Integer> property, int value) {
         return this.hasProperty(property, Integer.toString(value));
      }

      public StatePropertiesPredicate.Builder hasProperty(Property<Boolean> property, boolean value) {
         return this.hasProperty(property, Boolean.toString(value));
      }

      public <T extends Comparable<T> & StringRepresentable> StatePropertiesPredicate.Builder hasProperty(Property<T> property, T value) {
         return this.hasProperty(property, value.getSerializedName());
      }

      public StatePropertiesPredicate build() {
         return new StatePropertiesPredicate(this.matchers);
      }
   }

   static class ExactPropertyMatcher extends StatePropertiesPredicate.PropertyMatcher {
      private final String value;

      public ExactPropertyMatcher(String name, String value) {
         super(name);
         this.value = value;
      }

      protected <T extends Comparable<T>> boolean match(StateHolder<?, ?> properties, Property<T> propertyTarget) {
         T t = properties.getValue(propertyTarget);
         Optional<T> optional = propertyTarget.getValue(this.value);
         return optional.isPresent() && t.compareTo(optional.get()) == 0;
      }

      public JsonElement toJson() {
         return new JsonPrimitive(this.value);
      }
   }

   abstract static class PropertyMatcher {
      private final String name;

      public PropertyMatcher(String name) {
         this.name = name;
      }

      public <S extends StateHolder<?, S>> boolean match(StateDefinition<?, S> properties, S propertyToMatch) {
         Property<?> property = properties.getProperty(this.name);
         return property == null ? false : this.match(propertyToMatch, property);
      }

      protected abstract <T extends Comparable<T>> boolean match(StateHolder<?, ?> properties, Property<T> property);

      public abstract JsonElement toJson();

      public String getName() {
         return this.name;
      }

      public void checkState(StateDefinition<?, ?> properties, Consumer<String> propertyConsumer) {
         Property<?> property = properties.getProperty(this.name);
         if (property == null) {
            propertyConsumer.accept(this.name);
         }

      }
   }

   static class RangedPropertyMatcher extends StatePropertiesPredicate.PropertyMatcher {
      @Nullable
      private final String minValue;
      @Nullable
      private final String maxValue;

      public RangedPropertyMatcher(String name, @Nullable String minValue, @Nullable String maxValue) {
         super(name);
         this.minValue = minValue;
         this.maxValue = maxValue;
      }

      protected <T extends Comparable<T>> boolean match(StateHolder<?, ?> properties, Property<T> propertyTarget) {
         T t = properties.getValue(propertyTarget);
         if (this.minValue != null) {
            Optional<T> optional = propertyTarget.getValue(this.minValue);
            if (!optional.isPresent() || t.compareTo(optional.get()) < 0) {
               return false;
            }
         }

         if (this.maxValue != null) {
            Optional<T> optional1 = propertyTarget.getValue(this.maxValue);
            if (!optional1.isPresent() || t.compareTo(optional1.get()) > 0) {
               return false;
            }
         }

         return true;
      }

      public JsonElement toJson() {
         JsonObject jsonobject = new JsonObject();
         if (this.minValue != null) {
            jsonobject.addProperty("min", this.minValue);
         }

         if (this.maxValue != null) {
            jsonobject.addProperty("max", this.maxValue);
         }

         return jsonobject;
      }
   }
}
