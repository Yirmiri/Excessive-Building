package net.minecraft.client.gui.components;

import com.google.common.collect.Lists;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.AbstractList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.events.AbstractContainerEventHandler;
import net.minecraft.client.gui.components.events.ContainerEventHandler;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.narration.NarratableEntry;
import net.minecraft.client.gui.narration.NarratedElementType;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.navigation.ScreenDirection;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public abstract class AbstractSelectionList<E extends AbstractSelectionList.Entry<E>> extends AbstractContainerEventHandler implements Renderable, NarratableEntry {
   protected final Minecraft minecraft;
   protected final int itemHeight;
   private final List<E> children = new AbstractSelectionList.TrackedList();
   protected int width;
   protected int height;
   protected int y0;
   protected int y1;
   protected int x1;
   protected int x0;
   protected boolean centerListVertically = true;
   private double scrollAmount;
   private boolean renderSelection = true;
   private boolean renderHeader;
   protected int headerHeight;
   private boolean scrolling;
   @Nullable
   private E selected;
   private boolean renderBackground = true;
   private boolean renderTopAndBottom = true;
   @Nullable
   private E hovered;

   public AbstractSelectionList(Minecraft minecraft, int width, int height, int y0, int y1, int itemHeight) {
      this.minecraft = minecraft;
      this.width = width;
      this.height = height;
      this.y0 = y0;
      this.y1 = y1;
      this.itemHeight = itemHeight;
      this.x0 = 0;
      this.x1 = width;
   }

   public void setRenderSelection(boolean renderSelection) {
      this.renderSelection = renderSelection;
   }

   protected void setRenderHeader(boolean renderHeader, int headerHeight) {
      this.renderHeader = renderHeader;
      this.headerHeight = headerHeight;
      if (!renderHeader) {
         this.headerHeight = 0;
      }

   }

   public int getRowWidth() {
      return 220;
   }

   @Nullable
   public E getSelected() {
      return this.selected;
   }

   public void setSelected(@Nullable E selected) {
      this.selected = selected;
   }

   public E getFirstElement() {
      return this.children.get(0);
   }

   public void setRenderBackground(boolean renderBackground) {
      this.renderBackground = renderBackground;
   }

   public void setRenderTopAndBottom(boolean renderTopAndButton) {
      this.renderTopAndBottom = renderTopAndButton;
   }

   @Nullable
   public E getFocused() {
      return (E)(super.getFocused());
   }

   public final List<E> children() {
      return this.children;
   }

   protected void clearEntries() {
      this.children.clear();
      this.selected = null;
   }

   protected void replaceEntries(Collection<E> entries) {
      this.clearEntries();
      this.children.addAll(entries);
   }

   protected E getEntry(int index) {
      return this.children().get(index);
   }

   protected int addEntry(E entry) {
      this.children.add(entry);
      return this.children.size() - 1;
   }

   protected void addEntryToTop(E entry) {
      double d0 = (double)this.getMaxScroll() - this.getScrollAmount();
      this.children.add(0, entry);
      this.setScrollAmount((double)this.getMaxScroll() - d0);
   }

   protected boolean removeEntryFromTop(E entry) {
      double d0 = (double)this.getMaxScroll() - this.getScrollAmount();
      boolean flag = this.removeEntry(entry);
      this.setScrollAmount((double)this.getMaxScroll() - d0);
      return flag;
   }

   protected int getItemCount() {
      return this.children().size();
   }

   protected boolean isSelectedItem(int index) {
      return Objects.equals(this.getSelected(), this.children().get(index));
   }

   @Nullable
   protected final E getEntryAtPosition(double mouseX, double mouseY) {
      int i = this.getRowWidth() / 2;
      int j = this.x0 + this.width / 2;
      int k = j - i;
      int l = j + i;
      int i1 = Mth.floor(mouseY - (double)this.y0) - this.headerHeight + (int)this.getScrollAmount() - 4;
      int j1 = i1 / this.itemHeight;
      return (E)(mouseX < (double)this.getScrollbarPosition() && mouseX >= (double)k && mouseX <= (double)l && j1 >= 0 && i1 >= 0 && j1 < this.getItemCount() ? this.children().get(j1) : null);
   }

   public void updateSize(int width, int height, int y0, int y1) {
      this.width = width;
      this.height = height;
      this.y0 = y0;
      this.y1 = y1;
      this.x0 = 0;
      this.x1 = width;
   }

   public void setLeftPos(int x0) {
      this.x0 = x0;
      this.x1 = x0 + this.width;
   }

   protected int getMaxPosition() {
      return this.getItemCount() * this.itemHeight + this.headerHeight;
   }

   protected void clickedHeader(int mouseX, int mouseY) {
   }

   protected void renderHeader(GuiGraphics guiGraphics, int x, int y) {
   }

   protected void renderBackground(GuiGraphics guiGraphics) {
   }

   protected void renderDecorations(GuiGraphics guiGraphics, int mouseX, int mouseY) {
   }

   /**
    * Renders the graphical user interface (GUI) element.
    *
    * @param guiGraphics the GuiGraphics object used for rendering.
    * @param mouseX      the x-coordinate of the mouse cursor.
    * @param mouseY      the y-coordinate of the mouse cursor.
    * @param partialTick the partial tick time.
    */
   public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
      this.renderBackground(guiGraphics);
      int i = this.getScrollbarPosition();
      int j = i + 6;
      this.hovered = this.isMouseOver((double)mouseX, (double)mouseY) ? this.getEntryAtPosition((double)mouseX, (double)mouseY) : null;
      if (this.renderBackground) {
         guiGraphics.setColor(0.125F, 0.125F, 0.125F, 1.0F);
         int k = 32;
         guiGraphics.blit(Screen.BACKGROUND_LOCATION, this.x0, this.y0, (float)this.x1, (float)(this.y1 + (int)this.getScrollAmount()), this.x1 - this.x0, this.y1 - this.y0, 32, 32);
         guiGraphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
      }

      int l1 = this.getRowLeft();
      int l = this.y0 + 4 - (int)this.getScrollAmount();
      this.enableScissor(guiGraphics);
      if (this.renderHeader) {
         this.renderHeader(guiGraphics, l1, l);
      }

      this.renderList(guiGraphics, mouseX, mouseY, partialTick);
      guiGraphics.disableScissor();
      if (this.renderTopAndBottom) {
         int i1 = 32;
         guiGraphics.setColor(0.25F, 0.25F, 0.25F, 1.0F);
         guiGraphics.blit(Screen.BACKGROUND_LOCATION, this.x0, 0, 0.0F, 0.0F, this.width, this.y0, 32, 32);
         guiGraphics.blit(Screen.BACKGROUND_LOCATION, this.x0, this.y1, 0.0F, (float)this.y1, this.width, this.height - this.y1, 32, 32);
         guiGraphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
         int j1 = 4;
         guiGraphics.fillGradient(RenderType.guiOverlay(), this.x0, this.y0, this.x1, this.y0 + 4, -16777216, 0, 0);
         guiGraphics.fillGradient(RenderType.guiOverlay(), this.x0, this.y1 - 4, this.x1, this.y1, 0, -16777216, 0);
      }

      int i2 = this.getMaxScroll();
      if (i2 > 0) {
         int j2 = (int)((float)((this.y1 - this.y0) * (this.y1 - this.y0)) / (float)this.getMaxPosition());
         j2 = Mth.clamp(j2, 32, this.y1 - this.y0 - 8);
         int k1 = (int)this.getScrollAmount() * (this.y1 - this.y0 - j2) / i2 + this.y0;
         if (k1 < this.y0) {
            k1 = this.y0;
         }

         guiGraphics.fill(i, this.y0, j, this.y1, -16777216);
         guiGraphics.fill(i, k1, j, k1 + j2, -8355712);
         guiGraphics.fill(i, k1, j - 1, k1 + j2 - 1, -4144960);
      }

      this.renderDecorations(guiGraphics, mouseX, mouseY);
      RenderSystem.disableBlend();
   }

   protected void enableScissor(GuiGraphics guiGraphics) {
      guiGraphics.enableScissor(this.x0, this.y0, this.x1, this.y1);
   }

   protected void centerScrollOn(E entry) {
      this.setScrollAmount((double)(this.children().indexOf(entry) * this.itemHeight + this.itemHeight / 2 - (this.y1 - this.y0) / 2));
   }

   protected void ensureVisible(E entry) {
      int i = this.getRowTop(this.children().indexOf(entry));
      int j = i - this.y0 - 4 - this.itemHeight;
      if (j < 0) {
         this.scroll(j);
      }

      int k = this.y1 - i - this.itemHeight - this.itemHeight;
      if (k < 0) {
         this.scroll(-k);
      }

   }

   private void scroll(int scroll) {
      this.setScrollAmount(this.getScrollAmount() + (double)scroll);
   }

   public double getScrollAmount() {
      return this.scrollAmount;
   }

   public void setScrollAmount(double scroll) {
      this.scrollAmount = Mth.clamp(scroll, 0.0D, (double)this.getMaxScroll());
   }

   public int getMaxScroll() {
      return Math.max(0, this.getMaxPosition() - (this.y1 - this.y0 - 4));
   }

   public int getScrollBottom() {
      return (int)this.getScrollAmount() - this.height - this.headerHeight;
   }

   protected void updateScrollingState(double mouseX, double mouseY, int button) {
      this.scrolling = button == 0 && mouseX >= (double)this.getScrollbarPosition() && mouseX < (double)(this.getScrollbarPosition() + 6);
   }

   protected int getScrollbarPosition() {
      return this.width / 2 + 124;
   }

   /**
    * Called when a mouse button is clicked within the GUI element.
    * <p>
    * @return {@code true} if the event is consumed, {@code false} otherwise.
    *
    * @param mouseX the X coordinate of the mouse.
    * @param mouseY the Y coordinate of the mouse.
    * @param button the button that was clicked.
    */
   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      this.updateScrollingState(mouseX, mouseY, button);
      if (!this.isMouseOver(mouseX, mouseY)) {
         return false;
      } else {
         E e = this.getEntryAtPosition(mouseX, mouseY);
         if (e != null) {
            if (e.mouseClicked(mouseX, mouseY, button)) {
               E e1 = this.getFocused();
               if (e1 != e && e1 instanceof ContainerEventHandler) {
                  ContainerEventHandler containereventhandler = (ContainerEventHandler)e1;
                  containereventhandler.setFocused((GuiEventListener)null);
               }

               this.setFocused(e);
               this.setDragging(true);
               return true;
            }
         } else if (button == 0) {
            this.clickedHeader((int)(mouseX - (double)(this.x0 + this.width / 2 - this.getRowWidth() / 2)), (int)(mouseY - (double)this.y0) + (int)this.getScrollAmount() - 4);
            return true;
         }

         return this.scrolling;
      }
   }

   /**
    * Called when a mouse button is released within the GUI element.
    * <p>
    * @return {@code true} if the event is consumed, {@code false} otherwise.
    *
    * @param mouseX the X coordinate of the mouse.
    * @param mouseY the Y coordinate of the mouse.
    * @param button the button that was released.
    */
   public boolean mouseReleased(double mouseX, double mouseY, int button) {
      if (this.getFocused() != null) {
         this.getFocused().mouseReleased(mouseX, mouseY, button);
      }

      return false;
   }

   /**
    * Called when the mouse is dragged within the GUI element.
    * <p>
    * @return {@code true} if the event is consumed, {@code false} otherwise.
    *
    * @param mouseX the X coordinate of the mouse.
    * @param mouseY the Y coordinate of the mouse.
    * @param button the button that is being dragged.
    * @param dragX  the X distance of the drag.
    * @param dragY  the Y distance of the drag.
    */
   public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
      if (super.mouseDragged(mouseX, mouseY, button, dragX, dragY)) {
         return true;
      } else if (button == 0 && this.scrolling) {
         if (mouseY < (double)this.y0) {
            this.setScrollAmount(0.0D);
         } else if (mouseY > (double)this.y1) {
            this.setScrollAmount((double)this.getMaxScroll());
         } else {
            double d0 = (double)Math.max(1, this.getMaxScroll());
            int i = this.y1 - this.y0;
            int j = Mth.clamp((int)((float)(i * i) / (float)this.getMaxPosition()), 32, i - 8);
            double d1 = Math.max(1.0D, d0 / (double)(i - j));
            this.setScrollAmount(this.getScrollAmount() + dragY * d1);
         }

         return true;
      } else {
         return false;
      }
   }

   /**
    * Called when the mouse wheel is scrolled within the GUI element.
    * <p>
    * @return {@code true} if the event is consumed, {@code false} otherwise.
    *
    * @param mouseX the X coordinate of the mouse.
    * @param mouseY the Y coordinate of the mouse.
    * @param delta  the scrolling delta.
    */
   public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
      this.setScrollAmount(this.getScrollAmount() - delta * (double)this.itemHeight / 2.0D);
      return true;
   }

   public void setFocused(@Nullable GuiEventListener listener) {
      super.setFocused(listener);
      int i = this.children.indexOf(listener);
      if (i >= 0) {
         E e = this.children.get(i);
         this.setSelected(e);
         if (this.minecraft.getLastInputType().isKeyboard()) {
            this.ensureVisible(e);
         }
      }

   }

   @Nullable
   protected E nextEntry(ScreenDirection direction) {
      return this.nextEntry(direction, (p_93510_) -> {
         return true;
      });
   }

   @Nullable
   protected E nextEntry(ScreenDirection direction, Predicate<E> predicate) {
      return this.nextEntry(direction, predicate, this.getSelected());
   }

   @Nullable
   protected E nextEntry(ScreenDirection direction, Predicate<E> predicate, @Nullable E selected) {
      byte b0;
      switch (direction) {
         case RIGHT:
         case LEFT:
            b0 = 0;
            break;
         case UP:
            b0 = -1;
            break;
         case DOWN:
            b0 = 1;
            break;
         default:
            throw new IncompatibleClassChangeError();
      }

      int i = b0;
      if (!this.children().isEmpty() && i != 0) {
         int j;
         if (selected == null) {
            j = i > 0 ? 0 : this.children().size() - 1;
         } else {
            j = this.children().indexOf(selected) + i;
         }

         for(int k = j; k >= 0 && k < this.children.size(); k += i) {
            E e = this.children().get(k);
            if (predicate.test(e)) {
               return e;
            }
         }
      }

      return (E)null;
   }

   /**
    * Checks if the given mouse coordinates are over the GUI element.
    * <p>
    * @return {@code true} if the mouse is over the GUI element, {@code false} otherwise.
    *
    * @param mouseX the X coordinate of the mouse.
    * @param mouseY the Y coordinate of the mouse.
    */
   public boolean isMouseOver(double mouseX, double mouseY) {
      return mouseY >= (double)this.y0 && mouseY <= (double)this.y1 && mouseX >= (double)this.x0 && mouseX <= (double)this.x1;
   }

   protected void renderList(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
      int i = this.getRowLeft();
      int j = this.getRowWidth();
      int k = this.itemHeight - 4;
      int l = this.getItemCount();

      for(int i1 = 0; i1 < l; ++i1) {
         int j1 = this.getRowTop(i1);
         int k1 = this.getRowBottom(i1);
         if (k1 >= this.y0 && j1 <= this.y1) {
            this.renderItem(guiGraphics, mouseX, mouseY, partialTick, i1, i, j1, j, k);
         }
      }

   }

   protected void renderItem(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick, int index, int left, int top, int width, int height) {
      E e = this.getEntry(index);
      e.renderBack(guiGraphics, index, top, left, width, height, mouseX, mouseY, Objects.equals(this.hovered, e), partialTick);
      if (this.renderSelection && this.isSelectedItem(index)) {
         int i = this.isFocused() ? -1 : -8355712;
         this.renderSelection(guiGraphics, top, width, height, i, -16777216);
      }

      e.render(guiGraphics, index, top, left, width, height, mouseX, mouseY, Objects.equals(this.hovered, e), partialTick);
   }

   protected void renderSelection(GuiGraphics guiGraphics, int top, int width, int height, int outerColor, int innerColor) {
      int i = this.x0 + (this.width - width) / 2;
      int j = this.x0 + (this.width + width) / 2;
      guiGraphics.fill(i, top - 2, j, top + height + 2, outerColor);
      guiGraphics.fill(i + 1, top - 1, j - 1, top + height + 1, innerColor);
   }

   public int getRowLeft() {
      return this.x0 + this.width / 2 - this.getRowWidth() / 2 + 2;
   }

   public int getRowRight() {
      return this.getRowLeft() + this.getRowWidth();
   }

   protected int getRowTop(int index) {
      return this.y0 + 4 - (int)this.getScrollAmount() + index * this.itemHeight + this.headerHeight;
   }

   protected int getRowBottom(int index) {
      return this.getRowTop(index) + this.itemHeight;
   }

   public NarratableEntry.NarrationPriority narrationPriority() {
      if (this.isFocused()) {
         return NarratableEntry.NarrationPriority.FOCUSED;
      } else {
         return this.hovered != null ? NarratableEntry.NarrationPriority.HOVERED : NarratableEntry.NarrationPriority.NONE;
      }
   }

   @Nullable
   protected E remove(int index) {
      E e = this.children.get(index);
      return (E)(this.removeEntry(this.children.get(index)) ? e : null);
   }

   protected boolean removeEntry(E entry) {
      boolean flag = this.children.remove(entry);
      if (flag && entry == this.getSelected()) {
         this.setSelected((E)null);
      }

      return flag;
   }

   @Nullable
   protected E getHovered() {
      return this.hovered;
   }

   void bindEntryToSelf(AbstractSelectionList.Entry<E> entry) {
      entry.list = this;
   }

   protected void narrateListElementPosition(NarrationElementOutput narrationElementOutput, E entry) {
      List<E> list = this.children();
      if (list.size() > 1) {
         int i = list.indexOf(entry);
         if (i != -1) {
            narrationElementOutput.add(NarratedElementType.POSITION, Component.translatable("narrator.position.list", i + 1, list.size()));
         }
      }

   }

   public ScreenRectangle getRectangle() {
      return new ScreenRectangle(this.x0, this.y0, this.x1 - this.x0, this.y1 - this.y0);
   }

   @OnlyIn(Dist.CLIENT)
   protected abstract static class Entry<E extends AbstractSelectionList.Entry<E>> implements GuiEventListener {
      /** @deprecated */
      @Deprecated
      AbstractSelectionList<E> list;

      /**
       * Sets the focus state of the GUI element.
       *
       * @param focused {@code true} to apply focus, {@code false} to remove focus
       */
      public void setFocused(boolean focused) {
      }

      public boolean isFocused() {
         return this.list.getFocused() == this;
      }

      public abstract void render(GuiGraphics guiGraphics, int index, int top, int left, int width, int height, int mouseX, int mouseY, boolean hovering, float partialTick);

      public void renderBack(GuiGraphics guiGraphics, int index, int top, int left, int width, int height, int mouseX, int mouseY, boolean isMouseOver, float partialTick) {
      }

      /**
       * Checks if the given mouse coordinates are over the GUI element.
       * <p>
       * @return {@code true} if the mouse is over the GUI element, {@code false} otherwise.
       *
       * @param mouseX the X coordinate of the mouse.
       * @param mouseY the Y coordinate of the mouse.
       */
      public boolean isMouseOver(double mouseX, double mouseY) {
         return Objects.equals(this.list.getEntryAtPosition(mouseX, mouseY), this);
      }
   }

   @OnlyIn(Dist.CLIENT)
   class TrackedList extends AbstractList<E> {
      private final List<E> delegate = Lists.newArrayList();

      public E get(int index) {
         return this.delegate.get(index);
      }

      public int size() {
         return this.delegate.size();
      }

      public E set(int index, E entry) {
         E e = this.delegate.set(index, entry);
         AbstractSelectionList.this.bindEntryToSelf(entry);
         return e;
      }

      public void add(int index, E entry) {
         this.delegate.add(index, entry);
         AbstractSelectionList.this.bindEntryToSelf(entry);
      }

      public E remove(int index) {
         return this.delegate.remove(index);
      }
   }
}
