package net.minecraft.client.gui.components;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public abstract class AbstractScrollWidget extends AbstractWidget implements Renderable, GuiEventListener {
   private static final int BORDER_COLOR_FOCUSED = -1;
   private static final int BORDER_COLOR = -6250336;
   private static final int BACKGROUND_COLOR = -16777216;
   private static final int INNER_PADDING = 4;
   private double scrollAmount;
   private boolean scrolling;

   public AbstractScrollWidget(int x, int y, int width, int height, Component message) {
      super(x, y, width, height, message);
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (!this.visible) {
         return false;
      } else {
         boolean flag = this.withinContentAreaPoint(mouseX, mouseY);
         boolean flag1 = this.scrollbarVisible() && mouseX >= (double)(this.getX() + this.width) && mouseX <= (double)(this.getX() + this.width + 8) && mouseY >= (double)this.getY() && mouseY < (double)(this.getY() + this.height);
         if (flag1 && button == 0) {
            this.scrolling = true;
            return true;
         } else {
            return flag || flag1;
         }
      }
   }

   public boolean mouseReleased(double mouseX, double mouseY, int button) {
      if (button == 0) {
         this.scrolling = false;
      }

      return super.mouseReleased(mouseX, mouseY, button);
   }

   public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
      if (this.visible && this.isFocused() && this.scrolling) {
         if (mouseY < (double)this.getY()) {
            this.setScrollAmount(0.0D);
         } else if (mouseY > (double)(this.getY() + this.height)) {
            this.setScrollAmount((double)this.getMaxScrollAmount());
         } else {
            int i = this.getScrollBarHeight();
            double d0 = (double)Math.max(1, this.getMaxScrollAmount() / (this.height - i));
            this.setScrollAmount(this.scrollAmount + dragY * d0);
         }

         return true;
      } else {
         return false;
      }
   }

   /**
    * Called when the mouse wheel is scrolled within the GUI element.
    * <p>
    * @return {@code true} if the event is consumed, {@code false} otherwise.
    *
    * @param mouseX the X coordinate of the mouse.
    * @param mouseY the Y coordinate of the mouse.
    * @param delta  the scrolling delta.
    */
   public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
      if (!this.visible) {
         return false;
      } else {
         this.setScrollAmount(this.scrollAmount - delta * this.scrollRate());
         return true;
      }
   }

   /**
    * Called when a keyboard key is pressed within the GUI element.
    * <p>
    * @return {@code true} if the event is consumed, {@code false} otherwise.
    *
    * @param keyCode   the key code of the pressed key.
    * @param scanCode  the scan code of the pressed key.
    * @param modifiers the keyboard modifiers.
    */
   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
      boolean flag = keyCode == 265;
      boolean flag1 = keyCode == 264;
      if (flag || flag1) {
         double d0 = this.scrollAmount;
         this.setScrollAmount(this.scrollAmount + (double)(flag ? -1 : 1) * this.scrollRate());
         if (d0 != this.scrollAmount) {
            return true;
         }
      }

      return super.keyPressed(keyCode, scanCode, modifiers);
   }

   public void renderWidget(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
      if (this.visible) {
         this.renderBackground(guiGraphics);
         guiGraphics.enableScissor(this.getX() + 1, this.getY() + 1, this.getX() + this.width - 1, this.getY() + this.height - 1);
         guiGraphics.pose().pushPose();
         guiGraphics.pose().translate(0.0D, -this.scrollAmount, 0.0D);
         this.renderContents(guiGraphics, mouseX, mouseY, partialTick);
         guiGraphics.pose().popPose();
         guiGraphics.disableScissor();
         this.renderDecorations(guiGraphics);
      }
   }

   private int getScrollBarHeight() {
      return Mth.clamp((int)((float)(this.height * this.height) / (float)this.getContentHeight()), 32, this.height);
   }

   protected void renderDecorations(GuiGraphics guiGraphics) {
      if (this.scrollbarVisible()) {
         this.renderScrollBar(guiGraphics);
      }

   }

   protected int innerPadding() {
      return 4;
   }

   protected int totalInnerPadding() {
      return this.innerPadding() * 2;
   }

   protected double scrollAmount() {
      return this.scrollAmount;
   }

   protected void setScrollAmount(double scrollAmount) {
      this.scrollAmount = Mth.clamp(scrollAmount, 0.0D, (double)this.getMaxScrollAmount());
   }

   protected int getMaxScrollAmount() {
      return Math.max(0, this.getContentHeight() - (this.height - 4));
   }

   private int getContentHeight() {
      return this.getInnerHeight() + 4;
   }

   protected void renderBackground(GuiGraphics guiGraphics) {
      this.renderBorder(guiGraphics, this.getX(), this.getY(), this.getWidth(), this.getHeight());
   }

   protected void renderBorder(GuiGraphics guiGraphics, int x, int y, int width, int height) {
      int i = this.isFocused() ? -1 : -6250336;
      guiGraphics.fill(x, y, x + width, y + height, i);
      guiGraphics.fill(x + 1, y + 1, x + width - 1, y + height - 1, -16777216);
   }

   private void renderScrollBar(GuiGraphics guiGraphics) {
      int i = this.getScrollBarHeight();
      int j = this.getX() + this.width;
      int k = this.getX() + this.width + 8;
      int l = Math.max(this.getY(), (int)this.scrollAmount * (this.height - i) / this.getMaxScrollAmount() + this.getY());
      int i1 = l + i;
      guiGraphics.fill(j, l, k, i1, -8355712);
      guiGraphics.fill(j, l, k - 1, i1 - 1, -4144960);
   }

   protected boolean withinContentAreaTopBottom(int top, int bottom) {
      return (double)bottom - this.scrollAmount >= (double)this.getY() && (double)top - this.scrollAmount <= (double)(this.getY() + this.height);
   }

   protected boolean withinContentAreaPoint(double x, double y) {
      return x >= (double)this.getX() && x < (double)(this.getX() + this.width) && y >= (double)this.getY() && y < (double)(this.getY() + this.height);
   }

   protected boolean scrollbarVisible() {
      return this.getInnerHeight() > this.getHeight();
   }

   protected abstract int getInnerHeight();

   protected abstract double scrollRate();

   protected abstract void renderContents(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick);
}
