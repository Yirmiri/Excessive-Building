package net.minecraft.client;

import java.util.Arrays;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.FogType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Quaternionf;
import org.joml.Vector3f;

@OnlyIn(Dist.CLIENT)
public class Camera {
   private boolean initialized;
   private BlockGetter level;
   private Entity entity;
   private Vec3 position = Vec3.ZERO;
   private final BlockPos.MutableBlockPos blockPosition = new BlockPos.MutableBlockPos();
   private final Vector3f forwards = new Vector3f(0.0F, 0.0F, 1.0F);
   private final Vector3f up = new Vector3f(0.0F, 1.0F, 0.0F);
   private final Vector3f left = new Vector3f(1.0F, 0.0F, 0.0F);
   private float xRot;
   private float yRot;
   private final Quaternionf rotation = new Quaternionf(0.0F, 0.0F, 0.0F, 1.0F);
   private boolean detached;
   private float eyeHeight;
   private float eyeHeightOld;
   public static final float FOG_DISTANCE_SCALE = 0.083333336F;

   public void setup(BlockGetter level, Entity entity, boolean detached, boolean thirdPersonReverse, float partialTick) {
      this.initialized = true;
      this.level = level;
      this.entity = entity;
      this.detached = detached;
      this.setRotation(entity.getViewYRot(partialTick), entity.getViewXRot(partialTick));
      this.setPosition(Mth.lerp((double)partialTick, entity.xo, entity.getX()), Mth.lerp((double)partialTick, entity.yo, entity.getY()) + (double)Mth.lerp(partialTick, this.eyeHeightOld, this.eyeHeight), Mth.lerp((double)partialTick, entity.zo, entity.getZ()));
      if (detached) {
         if (thirdPersonReverse) {
            this.setRotation(this.yRot + 180.0F, -this.xRot);
         }

         this.move(-this.getMaxZoom(4.0D), 0.0D, 0.0D);
      } else if (entity instanceof LivingEntity && ((LivingEntity)entity).isSleeping()) {
         Direction direction = ((LivingEntity)entity).getBedOrientation();
         this.setRotation(direction != null ? direction.toYRot() - 180.0F : 0.0F, 0.0F);
         this.move(0.0D, 0.3D, 0.0D);
      }

   }

   public void tick() {
      if (this.entity != null) {
         this.eyeHeightOld = this.eyeHeight;
         this.eyeHeight += (this.entity.getEyeHeight() - this.eyeHeight) * 0.5F;
      }

   }

   /**
    * Checks for collision of the third person camera and returns the distance
    */
   private double getMaxZoom(double startingDistance) {
      for(int i = 0; i < 8; ++i) {
         float f = (float)((i & 1) * 2 - 1);
         float f1 = (float)((i >> 1 & 1) * 2 - 1);
         float f2 = (float)((i >> 2 & 1) * 2 - 1);
         f *= 0.1F;
         f1 *= 0.1F;
         f2 *= 0.1F;
         Vec3 vec3 = this.position.add((double)f, (double)f1, (double)f2);
         Vec3 vec31 = new Vec3(this.position.x - (double)this.forwards.x() * startingDistance + (double)f, this.position.y - (double)this.forwards.y() * startingDistance + (double)f1, this.position.z - (double)this.forwards.z() * startingDistance + (double)f2);
         HitResult hitresult = this.level.clip(new ClipContext(vec3, vec31, ClipContext.Block.VISUAL, ClipContext.Fluid.NONE, this.entity));
         if (hitresult.getType() != HitResult.Type.MISS) {
            double d0 = hitresult.getLocation().distanceTo(this.position);
            if (d0 < startingDistance) {
               startingDistance = d0;
            }
         }
      }

      return startingDistance;
   }

   /**
    * Moves the render position relative to the view direction, for third person camera
    */
   protected void move(double distanceOffset, double verticalOffset, double horizontalOffset) {
      double d0 = (double)this.forwards.x() * distanceOffset + (double)this.up.x() * verticalOffset + (double)this.left.x() * horizontalOffset;
      double d1 = (double)this.forwards.y() * distanceOffset + (double)this.up.y() * verticalOffset + (double)this.left.y() * horizontalOffset;
      double d2 = (double)this.forwards.z() * distanceOffset + (double)this.up.z() * verticalOffset + (double)this.left.z() * horizontalOffset;
      this.setPosition(new Vec3(this.position.x + d0, this.position.y + d1, this.position.z + d2));
   }

   protected void setRotation(float yRot, float xRot) {
      this.xRot = xRot;
      this.yRot = yRot;
      this.rotation.rotationYXZ(-yRot * ((float)Math.PI / 180F), xRot * ((float)Math.PI / 180F), 0.0F);
      this.forwards.set(0.0F, 0.0F, 1.0F).rotate(this.rotation);
      this.up.set(0.0F, 1.0F, 0.0F).rotate(this.rotation);
      this.left.set(1.0F, 0.0F, 0.0F).rotate(this.rotation);
   }

   /**
    * Sets the position and blockpos of the active render
    */
   protected void setPosition(double x, double y, double z) {
      this.setPosition(new Vec3(x, y, z));
   }

   protected void setPosition(Vec3 pos) {
      this.position = pos;
      this.blockPosition.set(pos.x, pos.y, pos.z);
   }

   public Vec3 getPosition() {
      return this.position;
   }

   public BlockPos getBlockPosition() {
      return this.blockPosition;
   }

   public float getXRot() {
      return this.xRot;
   }

   public float getYRot() {
      return this.yRot;
   }

   public Quaternionf rotation() {
      return this.rotation;
   }

   public Entity getEntity() {
      return this.entity;
   }

   public boolean isInitialized() {
      return this.initialized;
   }

   public boolean isDetached() {
      return this.detached;
   }

   public Camera.NearPlane getNearPlane() {
      Minecraft minecraft = Minecraft.getInstance();
      double d0 = (double)minecraft.getWindow().getWidth() / (double)minecraft.getWindow().getHeight();
      double d1 = Math.tan((double)((float)minecraft.options.fov().get().intValue() * ((float)Math.PI / 180F)) / 2.0D) * (double)0.05F;
      double d2 = d1 * d0;
      Vec3 vec3 = (new Vec3(this.forwards)).scale((double)0.05F);
      Vec3 vec31 = (new Vec3(this.left)).scale(d2);
      Vec3 vec32 = (new Vec3(this.up)).scale(d1);
      return new Camera.NearPlane(vec3, vec31, vec32);
   }

   public FogType getFluidInCamera() {
      if (!this.initialized) {
         return FogType.NONE;
      } else {
         FluidState fluidstate = this.level.getFluidState(this.blockPosition);
         if (fluidstate.is(FluidTags.WATER) && this.position.y < (double)((float)this.blockPosition.getY() + fluidstate.getHeight(this.level, this.blockPosition))) {
            return FogType.WATER;
         } else {
            Camera.NearPlane camera$nearplane = this.getNearPlane();

            for(Vec3 vec3 : Arrays.asList(camera$nearplane.forward, camera$nearplane.getTopLeft(), camera$nearplane.getTopRight(), camera$nearplane.getBottomLeft(), camera$nearplane.getBottomRight())) {
               Vec3 vec31 = this.position.add(vec3);
               BlockPos blockpos = BlockPos.containing(vec31);
               FluidState fluidstate1 = this.level.getFluidState(blockpos);
               if (fluidstate1.is(FluidTags.LAVA)) {
                  if (vec31.y <= (double)(fluidstate1.getHeight(this.level, blockpos) + (float)blockpos.getY())) {
                     return FogType.LAVA;
                  }
               } else {
                  BlockState blockstate = this.level.getBlockState(blockpos);
                  if (blockstate.is(Blocks.POWDER_SNOW)) {
                     return FogType.POWDER_SNOW;
                  }
               }
            }

            return FogType.NONE;
         }
      }
   }

   public final Vector3f getLookVector() {
      return this.forwards;
   }

   public final Vector3f getUpVector() {
      return this.up;
   }

   public final Vector3f getLeftVector() {
      return this.left;
   }

   public void reset() {
      this.level = null;
      this.entity = null;
      this.initialized = false;
   }

   @OnlyIn(Dist.CLIENT)
   public static class NearPlane {
      final Vec3 forward;
      private final Vec3 left;
      private final Vec3 up;

      NearPlane(Vec3 forward, Vec3 left, Vec3 up) {
         this.forward = forward;
         this.left = left;
         this.up = up;
      }

      public Vec3 getTopLeft() {
         return this.forward.add(this.up).add(this.left);
      }

      public Vec3 getTopRight() {
         return this.forward.add(this.up).subtract(this.left);
      }

      public Vec3 getBottomLeft() {
         return this.forward.subtract(this.up).add(this.left);
      }

      public Vec3 getBottomRight() {
         return this.forward.subtract(this.up).subtract(this.left);
      }

      public Vec3 getPointOnPlane(float leftScale, float upScale) {
         return this.forward.add(this.up.scale((double)upScale)).subtract(this.left.scale((double)leftScale));
      }
   }
}
