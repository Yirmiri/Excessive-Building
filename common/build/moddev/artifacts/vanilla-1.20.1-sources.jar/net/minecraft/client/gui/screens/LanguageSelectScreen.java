package net.minecraft.client.gui.screens;

import net.minecraft.ChatFormatting;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.client.gui.navigation.CommonInputs;
import net.minecraft.client.resources.language.LanguageInfo;
import net.minecraft.client.resources.language.LanguageManager;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class LanguageSelectScreen extends OptionsSubScreen {
   private static final Component WARNING_LABEL = Component.literal("(").append(Component.translatable("options.languageWarning")).append(")").withStyle(ChatFormatting.GRAY);
   /**
    * The List GuiSlot object reference.
    */
   private LanguageSelectScreen.LanguageSelectionList packSelectionList;
   /**
    * Reference to the LanguageManager object.
    */
   final LanguageManager languageManager;

   public LanguageSelectScreen(Screen lastScreen, Options options, LanguageManager languageManager) {
      super(lastScreen, options, Component.translatable("options.language"));
      this.languageManager = languageManager;
   }

   protected void init() {
      this.packSelectionList = new LanguageSelectScreen.LanguageSelectionList(this.minecraft);
      this.addWidget(this.packSelectionList);
      this.addRenderableWidget(this.options.forceUnicodeFont().createButton(this.options, this.width / 2 - 155, this.height - 38, 150));
      this.addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, (p_288243_) -> {
         this.onDone();
      }).bounds(this.width / 2 - 155 + 160, this.height - 38, 150, 20).build());
      super.init();
   }

   void onDone() {
      LanguageSelectScreen.LanguageSelectionList.Entry languageselectscreen$languageselectionlist$entry = this.packSelectionList.getSelected();
      if (languageselectscreen$languageselectionlist$entry != null && !languageselectscreen$languageselectionlist$entry.code.equals(this.languageManager.getSelected())) {
         this.languageManager.setSelected(languageselectscreen$languageselectionlist$entry.code);
         this.options.languageCode = languageselectscreen$languageselectionlist$entry.code;
         this.minecraft.reloadResourcePacks();
         this.options.save();
      }

      this.minecraft.setScreen(this.lastScreen);
   }

   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
      if (CommonInputs.selected(keyCode)) {
         LanguageSelectScreen.LanguageSelectionList.Entry languageselectscreen$languageselectionlist$entry = this.packSelectionList.getSelected();
         if (languageselectscreen$languageselectionlist$entry != null) {
            languageselectscreen$languageselectionlist$entry.select();
            this.onDone();
            return true;
         }
      }

      return super.keyPressed(keyCode, scanCode, modifiers);
   }

   /**
    * Renders the graphical user interface (GUI) element.
    *
    * @param guiGraphics the GuiGraphics object used for rendering.
    * @param mouseX      the x-coordinate of the mouse cursor.
    * @param mouseY      the y-coordinate of the mouse cursor.
    * @param partialTick the partial tick time.
    */
   public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
      this.packSelectionList.render(guiGraphics, mouseX, mouseY, partialTick);
      guiGraphics.drawCenteredString(this.font, this.title, this.width / 2, 16, 16777215);
      guiGraphics.drawCenteredString(this.font, WARNING_LABEL, this.width / 2, this.height - 56, 8421504);
      super.render(guiGraphics, mouseX, mouseY, partialTick);
   }

   @OnlyIn(Dist.CLIENT)
   class LanguageSelectionList extends ObjectSelectionList<LanguageSelectScreen.LanguageSelectionList.Entry> {
      public LanguageSelectionList(Minecraft minecraft) {
         super(minecraft, LanguageSelectScreen.this.width, LanguageSelectScreen.this.height, 32, LanguageSelectScreen.this.height - 65 + 4, 18);
         String s = LanguageSelectScreen.this.languageManager.getSelected();
         LanguageSelectScreen.this.languageManager.getLanguages().forEach((p_265492_, p_265377_) -> {
            LanguageSelectScreen.LanguageSelectionList.Entry languageselectscreen$languageselectionlist$entry = new LanguageSelectScreen.LanguageSelectionList.Entry(p_265492_, p_265377_);
            this.addEntry(languageselectscreen$languageselectionlist$entry);
            if (s.equals(p_265492_)) {
               this.setSelected(languageselectscreen$languageselectionlist$entry);
            }

         });
         if (this.getSelected() != null) {
            this.centerScrollOn(this.getSelected());
         }

      }

      protected int getScrollbarPosition() {
         return super.getScrollbarPosition() + 20;
      }

      public int getRowWidth() {
         return super.getRowWidth() + 50;
      }

      protected void renderBackground(GuiGraphics guiGraphics) {
         LanguageSelectScreen.this.renderBackground(guiGraphics);
      }

      @OnlyIn(Dist.CLIENT)
      public class Entry extends ObjectSelectionList.Entry<LanguageSelectScreen.LanguageSelectionList.Entry> {
         final String code;
         private final Component language;
         private long lastClickTime;

         public Entry(String code, LanguageInfo language) {
            this.code = code;
            this.language = language.toComponent();
         }

         public void render(GuiGraphics guiGraphics, int index, int top, int left, int width, int height, int mouseX, int mouseY, boolean hovering, float partialTick) {
            guiGraphics.drawCenteredString(LanguageSelectScreen.this.font, this.language, LanguageSelectionList.this.width / 2, top + 1, 16777215);
         }

         /**
          * Called when a mouse button is clicked within the GUI element.
          * <p>
          * @return {@code true} if the event is consumed, {@code false} otherwise.
          *
          * @param mouseX the X coordinate of the mouse.
          * @param mouseY the Y coordinate of the mouse.
          * @param button the button that was clicked.
          */
         public boolean mouseClicked(double mouseX, double mouseY, int button) {
            if (button == 0) {
               this.select();
               if (Util.getMillis() - this.lastClickTime < 250L) {
                  LanguageSelectScreen.this.onDone();
               }

               this.lastClickTime = Util.getMillis();
               return true;
            } else {
               this.lastClickTime = Util.getMillis();
               return false;
            }
         }

         void select() {
            LanguageSelectionList.this.setSelected(this);
         }

         public Component getNarration() {
            return Component.translatable("narrator.select", this.language);
         }
      }
   }
}
